package constantes;

public enum Mensaje {
    TITULO_MENU("Menu de actividades"),
    OPC_1("1. Obtener números de la serie Fibonacci\n"),
    OPC_1_1("1. Ingresar números de la serie Fibonacci\n"),
    OPC_2("2. Cálculos matemáticos\n"),
    OPC_3("3. Salir"),
    MSN_FIBONACCI("Ingrese numero a deducir su serie Fibonacci"),
    OPC_2_MENU("MENU OPCION 2"),
    OPC_2_1(" 1. Calcular factorial de un número\n"),
    OPC_2_2("2. Obtener el promedio de n datos\n"),
    OPC_2_3("3. Para un grupo de n estudiantes, mostrar cuantos aprobaron y    reprobaron el curso.\n"),
            OPC_2_4("4. Regresar\n"),
    GRC("Gracias por preferirnos. ");

    private String mensajes;

    Mensaje(String mensaje) {
        this.mensajes = mensaje;
    }

    public String getMensaje() {
        return mensajes;
    }
}
