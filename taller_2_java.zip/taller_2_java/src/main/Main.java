package main;

import sun.plugin2.message.JavaObjectOpMessage;

import javax.swing.*;



import static constantes.Mensaje.*;
import static constantes.Mensaje.OPC_2_3;

public class Main {
    public static void main(String[] args) {
        boolean accion = true;

        while (accion ) {
            String opcion = JOptionPane.showInputDialog(null, TITULO_MENU.getMensaje() + "\n" + OPC_1.getMensaje() + "\n" + OPC_2
                    .getMensaje() + "\n" + OPC_3.getMensaje());

            switch (opcion) {

                case "1":
                    String num = JOptionPane.showInputDialog(null, OPC_1_1.getMensaje());

                    int leer = Integer.parseInt(num);

                    int n = leer;
                    int a = 0, b = 1, c;
                    JOptionPane.showMessageDialog(null, b + "");

                    for (int i = 2; i <= n; i++) {
                        c = a + b;
                        JOptionPane.showMessageDialog(null, c + "");

                        a = b;
                        b = c;

                    }

                    break;
                case "2":
                    String opcion2 = JOptionPane.showInputDialog(null, OPC_2_MENU.getMensaje() + "\n\n" + OPC_2_1.getMensaje() + "\n" + OPC_2_2
                            .getMensaje() + "\n" + OPC_2_3.getMensaje() + "\n" + OPC_2_4.getMensaje());
                    switch (opcion2) {
                        case "1":
                            String valor = JOptionPane.showInputDialog(null, OPC_2_1.getMensaje());
                            int numero = Integer.parseInt(valor), numFactorial = 1,numF=0;
                            for (int i = 1; i == numero; i++) {
                                numF = numFactorial * i;

                            }
                            JOptionPane.showMessageDialog(null, "el factorial de : " + numero + " es: " + numF);
                            break;
                        case "2":
                            String vallor = JOptionPane.showInputDialog(null, OPC_2_2.getMensaje() + "\n\nIngrese Cantidad de de numeros a registrar");
                            int cantidad = Integer.parseInt(vallor);
                            int numm = 0;
                            int contador = 1;
                            float promedio = 0;


                            while (contador <= cantidad) {
                                String vl = JOptionPane.showInputDialog("Ingrese el " + contador + "° numero");
                                int vlr = Integer.parseInt(vl);
                                numm = vlr + numm;
                                contador++;
                            }
                            promedio = (numm / cantidad);

                            JOptionPane.showMessageDialog(null, "El Promedio de " + numm + " entre: " + cantidad + " numeros que se ingresaron es: " + promedio);
                            break;
                        case "3":
                            String alumnoss = JOptionPane.showInputDialog(null, OPC_2_3.getMensaje() + "\n\n ingrese cantidad de estudiantes a evaluar nota");
                            int alumnos = Integer.parseInt(alumnoss);

                            int ap = 0, dp = 0;
                            float notas, arpbados = 0, reprobados = 0;

                            for (int x = 1; x <= alumnos; x++) {
                                String notaas = JOptionPane.showInputDialog("ingrese nota del " + x + "° estudiante");
                                notas = Integer.parseInt(notaas);
                                if (notas >= 3) {
                                    arpbados = arpbados + notas;
                                    ap++;
                                } else if (notas < 3) {
                                    reprobados = reprobados + notas;
                                    dp++;
                                }
                            }
                                   JOptionPane.showMessageDialog(null,"los alumnos que aprovaron son: " + ap + ".\n los que no: " + dp + ".\n en ntotal fueron " + alumnos + " alumnos en este curso");


                            break;
                        case "4":
                            int respuesta = JOptionPane.showConfirmDialog(null, "Regresara al menu principal", "aviso", JOptionPane.YES_OPTION);
                            if (respuesta == JOptionPane.YES_OPTION) {
                                accion = true;
                            } else JOptionPane.showMessageDialog(null, GRC.getMensaje());
                            break;
                        default:
                            accion = false;


                    }

                    break;
                case "3":
                    JOptionPane.showMessageDialog(null, GRC.getMensaje());

                    accion = false;
                    break;
                default:
                    accion = true;
            }


        }
    }
}